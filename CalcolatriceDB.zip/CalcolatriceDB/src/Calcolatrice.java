import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Stack;

public class Calcolatrice {

    private Connection conn;

    private long userId;

    public JPanel Pannello;
    private JButton Zero;
    private JButton Uno;
    private JButton Due;
    private JButton Tre;
    private JButton Quattro;
    private JButton Cinque;
    private JButton Sei;
    private JButton Sette;
    private JButton Otto;
    private JButton Nove;
    private JButton Piu;
    private JButton Meno;
    private JButton Per;
    private JButton Diviso;
    private JButton Display;
    private JButton Cancella;
    private JTextField TextField1;
    private JButton Parentesi1;
    private JButton Parentesi2;
    private JButton Convert;






public static String converti(String espressioneRPN) {
        Stack<String> stack = new Stack<>();

        for (String token : espressioneRPN.split("")) {
            if (isOperatore(token)) {
                String operand2 = stack.pop();
                String operand1 = stack.pop();
                String risultato = "(" + operand1 + token + operand2 + ")";
                stack.push(risultato);
            } else {
                stack.push(token);
            }
        }

        if (stack.size() == 1) {
            return stack.pop();
        } else {
            return "Errore: espressione non valida";
        }
    }

    public static boolean isOperatore(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/");
    }

    
    public static String calcola(String espressioneInfix) {
        try {
            return Double.toString(evalInfix(espressioneInfix));
        } catch (Exception e) {
            return "Errore: espressione non valida";
        }
    }



    private static double evalInfix(String espressioneInfix) {
        Stack<Double> operandStack = new Stack<>();
        Stack<Character> operatorStack = new Stack<>();

        for (int i = 0; i < espressioneInfix.length(); i++) {
            char carattere = espressioneInfix.charAt(i);
            if (Character.isDigit(carattere)) {
                StringBuilder numero = new StringBuilder();
                while (i < espressioneInfix.length() && (Character.isDigit(espressioneInfix.charAt(i)) || espressioneInfix.charAt(i) == '.')) {
                    numero.append(espressioneInfix.charAt(i));
                    i++;
                }
                i--;
                operandStack.push(Double.parseDouble(numero.toString()));
            } else if (carattere == '(') {
                operatorStack.push(carattere);
            } else if (carattere == ')') {
                while (!operatorStack.isEmpty() && operatorStack.peek() != '(') {
                    double op2 = operandStack.pop();
                    double op1 = operandStack.pop();
                    char operatore = operatorStack.pop();
                    double risultato = applicaOperatore(op1, operatore, op2);
                    operandStack.push(risultato);
                }
                operatorStack.pop(); // Rimuovi la parentesi aperta.
            } else if (isOperatore(String.valueOf(carattere))) {
                while (!operatorStack.isEmpty() && precedenza(operatorStack.peek()) >= precedenza(carattere)) {
                    double op2 = operandStack.pop();
                    double op1 = operandStack.pop();
                    char operatore = operatorStack.pop();
                    double risultato = applicaOperatore(op1, operatore, op2);
                    operandStack.push(risultato);
                }
                operatorStack.push(carattere);
            }
        }

        while (!operatorStack.isEmpty()) {
            double op2 = operandStack.pop();
            double op1 = operandStack.pop();
            char operatore = operatorStack.pop();
            double risultato = applicaOperatore(op1, operatore, op2);
            operandStack.push(risultato);
        }

        return operandStack.pop();
    }

    private static double applicaOperatore(double op1, char operatore, double op2) {
        switch (operatore) {
            case '+':
                return op1 + op2;
            case '-':
                return op1 - op2;
            case '*':
                return op1 * op2;
            case '/':
                if (op2 == 0) {
                    throw new ArithmeticException("Divisione per zero");
                }
                return op1 / op2;
            default:
                throw new IllegalArgumentException("Operatore sconosciuto: " + operatore);
        }
    }

    private static int precedenza(char operatore) {
        switch (operatore) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            default:
                return 0; // Operatori non validi o parentesi.
        }
    }

    public Calcolatrice(long u, Connection c) {

        this.userId=u;
        this.conn=c;
        Zero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "0");
            }
        });

        Uno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "1");
            }
        });

        Due.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "2");
            }
        });

        Tre.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "3");
            }
        });

        Quattro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "4");
            }
        });

        Cinque.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "5");
            }
        });

        Sei.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "6");
            }
        });

        Sette.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "7");
            }
        });

        Otto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "8");
            }
        });

        Nove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "9");
            }
        });

        Piu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "+");
            }
        });

        Meno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "-");
            }
        });

        Per.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "*");
            }
        });

        Diviso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "/");
            }
        });

        Parentesi1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "(");
            }
        });

        Parentesi2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + ")");
            }
        });

        Cancella.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText("");
            }
        });

        Display.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery("SELECT Operation, Result from Operations WHERE IdUser ="+userId);
                    String toAdd="";

                    while(rs.next()){
                        toAdd+="•"+rs.getString("Operation")+"\t= "+rs.getString("Result")+"\n";
                    }
                    JOptionPane.showMessageDialog(null, toAdd);






                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }

            }
        });

        Convert.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String espressione = TextField1.getText();
                String espressioneElaborata = converti(espressione);
                String risultato= calcola(espressioneElaborata);

                try {
                    Statement stmt = conn.createStatement();
                    stmt.executeUpdate("INSERT INTO `operations` (`Id`, `IdUser`, `Operation`, `Result`) VALUES (NULL, '" + userId + "', '" + espressioneElaborata + "', '" + risultato + "')");


                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }


                TextField1.setText(risultato);
            }
        });



    }

}