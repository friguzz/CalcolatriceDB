import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;

import static java.lang.Long.parseLong;


public class LoginClass {
    static Connection connection =null;
    private JPanel Pannello;
    private JTextField usernameInput;
    private JPasswordField passwordInput;
    private JLabel passwordtxt;
    private JButton loginButton;
    private JButton registerButton;

    public static String getSHA256Hash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(input.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedHash) {
                String hex = Integer.toHexString(0xff & b);
                hexString.append(hex.length() == 1 ? '0' : "").append(hex);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    public LoginClass() {
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){

                if(usernameInput.getText().isEmpty() || passwordtxt.getText().isEmpty()){


                    JOptionPane.showMessageDialog(null, "Le credenziali non sono valide! ");
                    return;
                }
                try {

                    Statement stmt = connection.createStatement();
                    String password = getSHA256Hash(passwordInput.getText());
                    ResultSet rs = stmt.executeQuery("select Id from users where Username ='"+usernameInput.getText()+"'and Password='"+password+"'");


                    if(rs.next()){

                        long user = parseLong(rs.getString("Id"));
                        JFrame frame = new JFrame("Calcolatrice");
                        frame.setContentPane(new Calcolatrice(user, connection).Pannello);
                        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        frame.pack();
                        frame.setVisible(true);



                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Le credenziali non sono valide! ");
                    }





                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }



            }
        });
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(usernameInput.getText().isEmpty() || passwordtxt.getText().isEmpty()){


                    JOptionPane.showMessageDialog(null, "Le credenziali non sono valide! ");
                    return;
                }


                try {

                    Statement stmt = connection.createStatement();
                    String password = getSHA256Hash(passwordInput.getText());
                    ResultSet rs = stmt.executeQuery("select * from users where username ='"+usernameInput.getText()+"'");



                    if(rs.next()){
                        JOptionPane.showMessageDialog(null, "L'utente è già registrato ");



                    }
                    else{
                        stmt.executeUpdate("INSERT INTO `users` (`Id`, `Username`, `Password`) VALUES (NULL,' "+ usernameInput.getText()+"', '"+password+"')");
                        JOptionPane.showMessageDialog(null, "Registrazione avvenuta con successo, ora è possibile effettuare il login");

                    }





                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }








            }
        });
    }

    public static void main(String[] args) throws SQLException {
        connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1/eserciziosql", "root", "");
        JFrame frame = new JFrame("Calcolatrice");
        frame.setContentPane(new LoginClass().Pannello);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
